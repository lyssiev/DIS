document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tabButton');
    const tabPanes = document.querySelectorAll('.tabPane');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));
            this.classList.add('active');
            document.getElementById(this.getAttribute('data-tab')).classList.add('active');
        });
    });

    // Email functionality
    const emailEntries = document.querySelectorAll('.emailEntry');
    const inboxView = document.querySelector('.inboxView');
    const emailView = document.querySelector('.emailView'); 
    const backButton = document.querySelector('.backToInbox');
    const emailSubject = document.querySelector('.emailViewSubject');
    const emailSender = document.querySelector('.emailViewSender');
    const emailBody = document.querySelector('.emailBody');

    const emails = {
        1: {
            subject: "Next Steps",
            sender: "AEGI Good Guys Inc. <goodguys@cheese.com>",
            date: "July 13 2025",
            body: "Hello Agent,<br><br> Following your success cracking the Caeser Cipher, we now have access to some cameras of note - maybe where they're based? Either way some of the posts on their blog seem to indicate an interest in some specific features around that area, we also have been watching 4 of them too... <br><br> I would recommend you cross reference the emails we've forwarded you and the blog and see what they have in common, and in what order...<br><br> Sincerely,<br> AEGI Good Guys"
        },
        2: {
            subject: "Cheese",
            sender: "AEGI Good Guys Inc. <goodguys@cheese.com>",
            date: "July 10 2025",
            body: "Discounted Cheese at Walmart! 1$ per wheel of cheese <br><br> Sincerely,<br> AEGI Good Guys"
        },
        3: {
            subject: "Goose On The Loose",
            sender: "AEGI Good Guys Inc. <goodguys@cheese.com>",
            date: "July 7 2025",
            body: "Small town Seskechuan subject to geese rampage<br><br> Sincerely,<br> AEGI Good Guys"
        },

        4: {
            subject: "The Worst 8 Ball Player",
            sender: "AEGI Good Guys Inc. <goodguys@cheese.com>",
            date:"July 5 2025",
            body: "The worst 8 ball player in the world found in Exeter <br><br> Sincerely,<br> AEGI Good Guys"
        },

        5: {
            subject: "Local Menace eats Frozen Peas",
            sender: "AEGI Good Guys Inc. <goodguys@cheese.com>",
            date: "July 4 2025",
            body: "Local Menace who eats frozen peas found in Somserset <br><br> Sincerely,<br> AEGI Good Guys"
        }

        
    };
emailEntries.forEach(entry => {
    entry.addEventListener('click', function() {
        const emailId = this.getAttribute('data-email-id');
        const email = emails[emailId];
        
        if (email) {
            emailSubject.textContent = email.subject;
            emailSender.textContent = email.sender;
            document.querySelector('.emailViewDate').textContent = email.date;
            emailBody.innerHTML = email.body;
            
            inboxView.style.display = 'none';
            emailView.style.display = 'block';
        }
    });
});

    backButton.addEventListener('click', function() {
        inboxView.style.display = 'block';
        emailView.style.display = 'none';
    });
});